from .main import obfuscate
